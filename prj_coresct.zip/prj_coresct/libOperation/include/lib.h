#ifndef LIB_H_INCLUDED
#define LIB_H_INCLUDED

	int __strcmp(char *, int, char *, int);//redefinition de la fonction de compraision
	char *coreAdd(char *, int, char *, int);
	char *add(char *, int, char *, int); // prototype de l'add
	char *sub(char *, int, char *, int); // prototype de la soustraction
	char *mult(char*, int, char*, int); // multiplication
	char *division(char*, int, char*, int); // division
	int taille(char * str); //calcul la taille
	char *strcpy(char *, const char *); //fonction de recopi d'un tableau
	char * complement(char *, int, int); // fonction qui fait le complement d'un nombre

	



#endif // LIB_H_INCLUDED
