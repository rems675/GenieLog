#include <iostream>
#include "../libOperation/include/lib.h"

using namespace std;

int main(int argc, char *argv[])
{
	int sizeOfLeft=0, sizeOfRight=0, memory=-2; //taille des chiffre a gauche et a droite de l'oppérande
	bool zeroLelf=false, zeroRight=false; // false represent positif number
    char * res;
	int i=0;

	cout<<argv[1] << argv[2] << argv[3]<<endl;
	
	/**traintement des 0***/
	if(argv[1][0]=='-')
	{
		i=1;
		while(argv[1][i++]=='0')
			zeroLelf=true;

	}
	else
	{
		i=0;
		while(argv[1][i++]=='0')
			zeroLelf=true;

	}
	
	i=0;
	while(argv[3][i++]=='0')
			zeroRight=true;

	
	
	/**********************/
	if(argv[2][0]=='+')
	{
		if(argv[1][0]=='-')
		{
			
			if(zeroLelf)
			{
				cout<<"=  "<< argv[3]<<endl;
				return 0;
			}
			if(zeroRight)
			{
				cout<<"=  "<< argv[1]<<endl;
				return 0;
			}
			
				
			char*saveLeft=argv[1];
			++saveLeft;
			memory = __strcmp(saveLeft, taille(saveLeft), argv[3], taille(argv[3]));
			std::cout<<"memory"<<memory<<std::endl;
			switch(memory)
			{
				case 0:
					std::cout<<"identique"<<std::endl;
					 cout<<" = 0 "<<endl;
				break;

				case 1: // le chiffre gauche est plus grand
				res=sub(saveLeft,taille(saveLeft), argv[3], taille(argv[3]));
					 cout<<" = - " <<res<<endl;
				break;
					case -1: // le chiffre gauche est plus petit
				res=sub(argv[3], taille(argv[3]), argv[1], taille(argv[1]));//( grand, petit )
					cout<<" =  " <<res<<endl;
				break;
			}		 
			 
		}
		else
		{
			if(zeroLelf)
			{
				cout<<"=  "<< argv[3]<<endl;
				return 0;
			}
			if(zeroRight)
			{
				cout<<"=  "<< argv[1]<<endl;
				return 0;
			}
		    res=add(argv[1],taille(argv[1]), argv[3], taille(argv[3]));
            cout<<" = " <<res<<endl;
		}

	}
    if(argv[2][0]=='-')
	{
		if(argv[1][0]=='-')
		{
			if(zeroLelf)
			{
				cout<<"= - "<< argv[3]<<endl;
				return 0;
			}
			if(zeroRight)
			{
				cout<<"=  "<< argv[1]<<endl;
				return 0;
			}
			char*saveLeft=argv[1];
			++saveLeft;
			res=add(saveLeft,taille(saveLeft), argv[3], taille(argv[3]));
			cout<<" = - " <<res<<endl;
			
		}
		else
		{
			if(zeroLelf)
			{
				cout<<"= - "<< argv[3]<<endl;
				return 0;
			}
			if(zeroRight)
			{
				cout<<"=  "<< argv[1]<<endl;
				return 0;
			}
			memory = __strcmp(argv[1], taille(argv[1]), argv[3], taille(argv[3]));
			std::cout<<"memory"<<memory<<std::endl;
			switch(memory)
			{
				case 0:
					std::cout<<"identique"<<std::endl;
					 cout<<" = 0 "<<endl;
				break;

				case -1: // le chiffre gauche est plus petit
				
					res=sub(argv[1], taille(argv[1]), argv[3], taille(argv[3])); //apeler soustraction( grand, comp(petit) )

					cout<<" = - " <<res<<endl;
				break;
				
				case 1:
					//apeler sosutarction (grand, petit)
					res=sub(argv[1],taille(argv[1]), argv[3], taille(argv[3]));
					cout<<" =  " <<res<<endl;
				
				break;
			}

		}
   	}
   	
   	if(argv[2][0]=='x')
	{
		if(argv[1][0]=='-')
		{
			char*saveLeft=argv[1];
			++saveLeft;
			res=mult(saveLeft, taille(saveLeft), argv[3], taille(argv[3]));
			cout<<" = - "<<res<<endl;
			
		}
		else
		{
			res=mult(argv[1], taille(argv[1]), argv[3], taille(argv[3]));
			cout<<" =  "<<res<<endl;
		}
	}
	
if(argv[2][0]=='/')
	{
		if(argv[1][0]=='-')
		{
			memory = __strcmp(argv[1]+1, taille(argv[1]+1)-1, argv[3], taille(argv[3]));
			std::cout<<"memory"<<memory<<std::endl;
			switch(memory)
			{
				case 0:
					std::cout<<"identique"<<std::endl;
					 cout<<" = 1 "<<endl;
				break;

				case -1: // le chiffre gauche est plus petit
					cout<<" = 0 " <<endl;
				break;
				case 1:
					char*saveLeft=argv[1];
					++saveLeft;
					//apeler division (grand, petit)
					res=division(saveLeft, taille(saveLeft), argv[3], taille(argv[3]));
					cout<<" = - " <<res<<endl;
				break;
			}
		}
		else
		{
			memory = __strcmp(argv[1], taille(argv[1]) ,argv[3], taille(argv[3]));
			std::cout<<"memory"<<memory<<std::endl;
			switch(memory)
			{
				case 0:
					std::cout<<"identique"<<std::endl;
					 cout<<" = 1 "<<endl;
				break;

				case -1: // le chiffre gauche est plus petit
					cout<<" = 0 " <<endl;
				break;
				case 1:
					//apeler division (grand, petit)
					res=division(argv[1], taille(argv[1]), argv[3], taille(argv[3]));
					cout<<" =  " <<res<<endl;
				break;
			}
		}
			
	}	
    return 0;
}
