#include <iostream>
#include <cstring>


using namespace std;

int _strcmp(char *a, int sizea, char *b, int sizeb)
{
    int i=0;
    if(sizea>sizeb)
    {
        return 1;
    }
    if(sizea<sizeb)
    {
        return -1;
    }
    if(sizea==sizeb)
    {
        while(a[i]==b[i] && i!=sizea)
            i++;
        if(a[i]>b[i])
            return 1;
        if(a[i]<b[i])
            return -1;
    }
    return 0;
}

int main(int argc, char *argv[])
{
    int sizeOfLeft=0, sizeOfRigth=0, i=0; //taille des chiffre a gauche et a droite de l'oppérande

    while(argv[1][i]!='\0')
    {
        sizeOfLeft++;
        i++;
    }
    i=0;
    while(argv[3][i]!='\0')
    {
        sizeOfRigth++;
        i++;
    }

    int memory = _strcmp(argv[1],sizeOfLeft, argv[3], sizeOfRigth);

    switch(memory)
    {
        case 0:
        cout<<"G==D"<<endl;
        break;

    case 1:
        cout<<"G>D"<<endl;
        break;
    case-1:
        cout<<"G<D"<<endl;
        break;
    }


    return 0;
}
