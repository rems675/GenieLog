START=$(date +%s)
./param
END=$(date +%s)
DIFF=$(( $END - $START ))
TEMPS=$(bc <<< "scale=2; $DIFF/60")
echo "    *** Score shell CV terminé en $TEMPS minutes ou DIFF secondes" 
