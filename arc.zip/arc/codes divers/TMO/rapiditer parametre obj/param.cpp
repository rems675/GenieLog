#include <iostream>
#include <time.h>

using namespace std;

class A
{
public:
    int t;
    int s;
    const char * chaine;

    A();

};

A::A()
{
    chaine="111111199999999999999999999999999999999999999";
    t=43;
    s=2;
}

void addition(int a, int b, const char* c, int d, int e, const char * f )
{

}

int main()
{
    time_t start,end;
    double dif;
    int i;
     time (&start);
    for(i=0; i<2000000000; i++)
    {
            
   addition(obj1.s, obj1.t, obj1.chaine, obj2.s, obj2.t, obj2.chaine);
    }
     time (&end);
      dif = difftime (end,start);
      cout<<"tmp : " << dif;

    return 0;
}
