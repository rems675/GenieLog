#include <iostream>
#include <time.h>

using namespace std;

class A
{
public:
    int t;
    bool s;
    const char * chaine;

    A();

};

A::A()
{
    chaine="111111199999999999999999999999999999999999999";
    t=43;
    s=true;
}

void addition(A obj1, A obj2)
{

}

int main()
{
    time_t start,end;
    double dif;

    


    A obj1;
    A obj2;
    int i;
     time (&start);
    for(i=0; i<2000000000; i++)
    {
            addition(obj1, obj2);
    }
     time (&end);
      dif = difftime (end,start);
      cout<<"tmp : " << dif<<endl;

    return 0;
}
