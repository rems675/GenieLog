#include <iostream>
#include <time.h>

using namespace std;

char cmp(char a, char b)
{
	if (a==b) {return 0;}
	if(a>b) {return -1;}
	else {return 1;}
   
}

int main()
{
    time_t start,end;
    double dif;
    int i;
     time (&start);
    for(i=0; i<2000000000; i++)
    {        
		if(cmp(25, 255)==0);
		if(cmp(25, 155)==-1);
    }
     time (&end);
      dif = difftime (end,start);
      cout<<"tmp : " << dif;

    return 0;
}
