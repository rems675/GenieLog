#include <iostream>
#include <time.h>

using namespace std;

char cmp(char a, char b)
{
	if (a==b) {return 0;}
	if(a>b) {return -1;}
	else {return 1;}
   
}

int main()
{
	char retour=-2;
    time_t start,end;
    double dif;
    int i;
     time (&start);
    for(i=0; i<2000000000; i++)
    {        
		retour=cmp(25, 100);
		switch(retour)
		{
			case 0:
				break;
			case -1:
				break;
		}
    }
     time (&end);
      dif = difftime (end,start);
      cout<<"tmp : " << dif;

    return 0;
}
