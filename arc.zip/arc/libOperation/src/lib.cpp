#include <iostream>
#include "../include/lib.h"
#include <stdlib.h>

/**STRING COMPARE**/
int __strcmp(char *a, int sizea, char *b, int sizeb)
{
	int i=0;
	if(sizea>sizeb)// we check if the number left is higher than the other
	{
		return 1;
	}
	if(sizea<sizeb) //we check if the number left is lesser than the other
	{
		return -1;
	}
	if(sizea==sizeb)//we check if the number is like than the other
	{
		/* if the numbers are egal and we haven't run all the string
		 * we run through the string
		  */
		while(a[i]==b[i] && i!=sizea) 
		i++;
		if(a[i]>b[i]) // if a part of string are higher than te other return 1
			return 1;
		if(a[i]<b[i]) // reverse
			return -1;
	}
	return 0; // string are the same
}
/**CORE ADDITION**/
char * coreAdd(char * left, int sizeOfLeft, char * right, int sizeOfRight) {

    /* [ Determine which number is longer. ]
     * For visibility's sake, I'm aliasing "min" and "max" to the corresponding
     * values from "sizeOfLeft" and "sizeOfRight".
     * For the same reason I'm aliasing the pointers "small" and "big" to the
     * "left" and "right" array of characters.
     */
    int min = sizeOfRight; char * small = right;
    int max = sizeOfLeft;  char * big   = left;
    if (max < min) {
        max = min;        big   = small;
        min = sizeOfLeft; small = left;
    }


    /* [ Allocate space to store the result. ]
     * The result array of characters needs to have one more cell than the
     * bigger between right and left, so that's one more than "max".
     * 9 + 9 -> 18
     * 9 + 1 -> 10
     * The allocation itself needs to be nested in a try block to provide
     * exception handling when not enough space is available.
     */
    char * result;
    try {
        result = new char[max+1];
    }
    catch (...) { return NULL; } // This catches any exception and return NULL.


    /* [ Initialize. ] 
     * - Of course the carry needs to be 0 when first entering the loop.
     * - Also, we'll use "max" to address both the current value inside of "big"
     * and the current cell in the result array.
     * Because the result array has "max+1" cells, to access the right one using
     * the value of "max" we can either evaluate "max+1" each time we need it,
     * or save ourselves a considerable number of operations by adding "1" to
     * the value pointed by "result". (The same way we would move %edi by one 
     * char in assembly using "addb $1,%edi")
     * - Finally, the last cell of each array holds the "End Of String"
     * character: '\0' which value is "0". We need to set the last cell of the
     * result array with that same value for various reasons. 
     * (i.e: Use with "cout".)
     */
    char carry = 0;
    ++result;
    result[max] = 0; --min; --max;

    /* Now let's get to work people! */

    /* [ Phase 1/3 ]
     * We have to sum the values contained in the cells of the small and big
     * arrays, and store the result in the "result" array.
     * At each step we also need to add the carry.
     *
     *      Example 1:
     *      '1' + '2' = 49 + 50 =  99
     *                            -48
     *                           = 51 = '3'
     *      (Hence the - '0' below, because '0' = 48) (#1)
     *
     *      Example 2:
     *      '9' + '3' = 57 + 51 = 108
     *                            -48
     *                           = 60 = '<' --> 60 / 58 = 1 ( carry )
     *                                      --> 60 % 58 = 2 ( reminder )
     *      (Hence the '9'+1 below, because '9'-1 = 58) (#2)
     *
     * When a carry is produced, the reminder needs to be added 48 again to
     * match the character corresponding. (#3)
     * In the second example above, the reminder is 2. But the character of
     * value 2 is '2'. and '2' = 50 = 2 + 48
     */
    for (min ; min >= 0 ; --min, --max) {
        result[max] = big[max] + small[min] - '0' + carry; // (#1)
        carry       = result[max] / ('9'+1);  // (#2)
        result[max] = result[max] % ('9'+1);
        if (carry)       // (#3)
            result[max] = result[max] + '0';
    }


    /* [ Phase 2/3 ]
     * It's exactly the same principle as in phase 1, except we're done with
     * the small array, so we only need to propagate the carry on the values
     * from the big array.
     */
    for (max ; max >= 0 ; --max) {
        result[max] = big[max] + carry;
        carry       = result[max] / ('9'+1);
        result[max] = result[max] % ('9'+1);
        if (carry)
            result[max] = result[max] + '0';
        else
            while (max--)
                result[max] = big[max];
    }


    /* [ Phase 3/3 ]
     * The work is almost done.
     * The last operation may have raised a carry, in which case we need to set
     * the value of the first cell of our array with the character '1'.
     * But to access the cell of indice zero in our array, we first need to
     * switch back the pointer from one char so as to undo what was done during
     * initialization.
     */
    --result;
    if (carry)
        result[0] = '1';
    else
        result[0] = '0';


    /* [ Completion. ]
     * Return the pointer on the array with the result.
     * A problem with this algorithm is the leading zero when the last
     * addition fails to raise a carry.
     */
    return result;
}
/**ADDITON TREATMENT**/
char* add(char * left, int sizeOfLeft, char * right, int sizeOfRight)
{	
	int memory=-2;
	char * ret=NULL;		
	bool sign=false; // false represent positif number

	if(left[0]=='-' && right[0]!='-') 
	{		
		char*saveLeft=left;
		++left;	
		memory = __strcmp(left, sizeOfLeft-1, right, sizeOfRight);
		std::cout<<"memory"<<memory<<std::endl;
		switch(memory)
		{
			case 0:
				std::cout<<"identique"<<std::endl; 
				return NULL;
			break;
			
			case 1: // le chiffre gauche est plus grand
				sign=true;
			break;
		}
		
	return(coreAdd(left, sizeOfLeft-1, right, sizeOfRight));
	}
	else
	return(coreAdd(left, sizeOfLeft, right, sizeOfRight));
	
	/*
        for(int i =0; i<4; i++)
        {
            std::cout<<ret[i];
        }
        */
	//std::cout<<"sign final"<<sign<<std::endl;	
	
}

/**SUBSTRACTION**/
char *sub(char * left, int sizeOfLeft, char * right, int sizeOfRight)
{
	int max=0;
	if(sizeOfLeft>sizeOfRight)
		max=sizeOfLeft;
	if(sizeOfLeft<sizeOfRight)
		max=sizeOfRight;
	else
		max=sizeOfLeft;
		
	char * result;
    try {
        result = new char[max+1];
    }
    catch (...) { return NULL; } // This catches any exception and return NULL.
    
    
    char res=('7'-'0') - ('2'-'0');
    std::cout<<res<<std::endl;
  
   // for(int i=0; i<10; i++)
  
  // std::cout<<i+'7'-'0' <<"\t"<< '2'-'0'<<std::endl;
   /*
  
    for(int i=0; i<=9; i++)
    {
		if(i+'0' == '2'-'0')
		{
			std::cout<<"res = " << i<<std::endl;
			break;
		
		}			
	}
*/
		
			
}
