#ifndef LIB_H_INCLUDED
#define LIB_H_INCLUDED

	int __strcmp(char *, int, char *, int);//redefinition de la fonction de compraision
	char *coreAdd(char *, int, char *, int);
	char *add(char *, int, char *, int); // prototype
	char *sub(char *, int, char *, int); // prototype
	



#endif // LIB_H_INCLUDED
