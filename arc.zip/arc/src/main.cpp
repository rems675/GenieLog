#include <iostream>
#include "../libOperation/include/lib.h"

using namespace std;

int main(int argc, char *argv[])
{
	int sizeOfLeft=0, sizeOfRigth=0; //taille des chiffre a gauche et a droite de l'oppérande
    char * res;
	int i=0;
	
	cout<<argv[1] << argv[2] << argv[3]<<endl;;


	while(argv[1][i]!='\0')
	{
		sizeOfLeft++;
		i++;
	}
	i=0;
	while(argv[3][i]!='\0')
	{
		sizeOfRigth++;
		i++;
	}
	if(argv[2][0]=='+')
	{
		res=add(argv[1],sizeOfLeft, argv[3], sizeOfRigth);
        cout<<" = " <<res<<endl;
	}
    if(argv[2][0]=='-')
	{
		res=sub(argv[1],sizeOfLeft, argv[3], sizeOfRigth);
   	}
   


    return 0;
}
